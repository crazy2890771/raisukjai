/* Lucky Color offline cache — version changes on every build */
const CACHE="lucky-color-ca312b4a";
const FILES=["./", "index.html", "manifest.webmanifest", "fonts/cormorant-garamond-latin-500-normal.woff2", "fonts/cormorant-garamond-latin-600-normal.woff2", "fonts/noto-sans-thai-looped-latin-400-normal.woff2", "fonts/noto-sans-thai-looped-latin-500-normal.woff2", "fonts/noto-sans-thai-looped-latin-600-normal.woff2", "fonts/noto-sans-thai-looped-latin-700-normal.woff2", "fonts/noto-sans-thai-looped-thai-400-normal.woff2", "fonts/noto-sans-thai-looped-thai-500-normal.woff2", "fonts/noto-sans-thai-looped-thai-600-normal.woff2", "fonts/noto-sans-thai-looped-thai-700-normal.woff2", "icons/icon-192.png", "icons/icon-512.png", "icons/maskable-512.png", "icons/apple-touch-icon.png", "icons/favicon-32.png"];
self.addEventListener("install",e=>{ e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting())); });
self.addEventListener("activate",e=>{ e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())); });
self.addEventListener("fetch",e=>{
  const r=e.request; if(r.method!=="GET") return;
  const url=new URL(r.url); if(url.origin!==location.origin) return;
  if(r.mode==="navigate"){
    /* page: try the network for updates, fall back to the cached copy when offline */
    e.respondWith(fetch(r).then(res=>{ const cp=res.clone(); caches.open(CACHE).then(c=>c.put("index.html",cp)); return res; }).catch(()=>caches.match("index.html")));
    return;
  }
  e.respondWith(caches.match(r).then(hit=>hit||fetch(r).then(res=>{ if(res.ok){ const cp=res.clone(); caches.open(CACHE).then(c=>c.put(r,cp)); } return res; })));
});
